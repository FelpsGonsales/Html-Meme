/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gonsales
 */
class CalculadoraS {
   public static String contas="";
   public static double calculo(double A, double B, String contas){
       
       double resultado=0;
       if(contas.equals("adicao")){
          resultado = A + B;
       }else if (contas.equals("subtracao")){
          resultado = A - B; 
       }else if (contas.equals("multiplicacao")){
          resultado = A * B;  
       }else if (contas.equals("divisao")){
          resultado = A / B; 
}
       return resultado;
   }
}